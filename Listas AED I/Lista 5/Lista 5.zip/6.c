#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*Descrição: o procedimento conta e printa qual a letra que mais se repete
Entrada: vet[] (char)
Saida:
*/
void contaLetra(char vet[]) {
    int letras[26] = {0};  
    int i = 0;

    
    while (vet[i] != '\0') {
        if (isalpha(vet[i])) { 
            char c = tolower(vet[i]); 
            letras[c - 'a']++; 
        }
        i++;
    }

    
    int max = 0;
    int indice = 0;
    for (i = 0; i < 26; i++) {
        if (letras[i] > max) {
            max = letras[i];
            indice = i;
        }
    }

    printf("\nA letra mais usada foi '%c', aparecendo %d vezes.\n", indice + 'a', max);
}

int main() {
    char texto[500];

    printf("---Digite seu texto---\n");
    fgets(texto, sizeof(texto), stdin);

    contaLetra(texto);

    return 0;
}